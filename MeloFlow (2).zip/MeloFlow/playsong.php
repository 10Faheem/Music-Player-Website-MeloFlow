<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Play Song</title>
    <link rel="stylesheet" href="playsongstyle.css"> <!-- Link to your CSS file -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Link to Font Awesome for icons -->
</head>
<body>
    <div id="AllInBody">
        <div id="ContentWarpper">
            <div id="WholeCardContainer">
                <div id="MusicImg">
                    <img id="SongImg" src="image.jpg" alt="Song Image">
                </div>
                <div id="MusicDesc">
                    <h2 id="SongName"></h2>
                    <p id="Artist"></p>
                </div>
                <div id="MusicControls">
                    <div id="Previous">
                        <i class="fas fa-backward"></i>
                    </div>
                    <div id="PausePlay">
                        <i class="fas fa-play"></i>
                    </div>
                    <div id="Next">
                        <i class="fas fa-forward"></i>
                    </div>
                </div>
                <div id="VolumeControl">
                    <input type="range" id="VolumeSlider" min="0" max="100" value="50">
                </div>
                <div id="Progress_elements">
                    <div id="Progressduration">
                        <span id="Start">0:00</span>
                        <span id="End">0:00</span>
                    </div>
                    <div id="ProgressMeterContainer">
                        <div id="ProgrssMeterChild"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer>
        <p>&copy; <span id="Year"></span> MeloFlow. All rights reserved. | Design by <a href="#">Faheem&Burki</a></p>
    </footer>

    <?php
    include('connection.php');

    $songs = array();
    $song_title = "";
    $artist = "";
    $audio_file = "";
    $current_song_index = 0;

    // Fetch all songs
    $sql = "SELECT * FROM songs";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $songs[] = $row;
        }
    }

    if (isset($_GET['song_id'])) {
        $song_id = $_GET['song_id'];
        foreach ($songs as $index => $song) {
            if ($song['Song_ID'] == $song_id) {
                $current_song_index = $index;
                $song_title = $song['Song_title'];
                $artist = $song['Artist'];
                $audio_file = 'Songs/' . $song_title . '.mp3';
                break;
            }
        }
    }

    $conn->close();
    ?>

    <script>
        const songs = <?php echo json_encode($songs); ?>;
        let currentSongIndex = <?php echo $current_song_index; ?>;
        let audio = new Audio('<?php echo $audio_file; ?>');

        document.getElementById('SongName').textContent = '<?php echo $song_title; ?>';
        document.getElementById('Artist').textContent = '<?php echo $artist; ?>';

        document.getElementById('PausePlay').addEventListener('click', function() {
            if (audio.paused) {
                audio.play();
                this.querySelector('i').classList.replace('fa-play', 'fa-pause');
            } else {
                audio.pause();
                this.querySelector('i').classList.replace('fa-pause', 'fa-play');
            }
        });

        document.getElementById('Next').addEventListener('click', function() {
            currentSongIndex = (currentSongIndex + 1) % songs.length;
            loadSong(currentSongIndex);
        });

        document.getElementById('Previous').addEventListener('click', function() {
            currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
            loadSong(currentSongIndex);
        });

        document.getElementById('VolumeSlider').addEventListener('input', function() {
            audio.volume = this.value / 100;
        });

        function loadSong(index) {
            let song = songs[index];
            document.getElementById('SongName').textContent = song['Song_title'];
            document.getElementById('Artist').textContent = song['Artist'];
            audio.src = 'Songs/' + song['Song_title'] + '.mp3';
            audio.play();
            document.getElementById('PausePlay').querySelector('i').classList.replace('fa-play', 'fa-pause');
        }

        audio.addEventListener('ended', function() {
            currentSongIndex = (currentSongIndex + 1) % songs.length;
            loadSong(currentSongIndex);
        });

        audio.addEventListener('timeupdate', function() {
            let duration = audio.duration;
            let currentTime = audio.currentTime;
            if (!isNaN(duration)) {
                let totalMinutes = Math.floor(duration / 60);
                let totalSeconds = Math.floor(duration % 60);
                document.getElementById('End').textContent = totalMinutes + ":" + (totalSeconds < 10 ? "0" + totalSeconds : totalSeconds);

                let currentMinutes = Math.floor(currentTime / 60);
                let currentSeconds = Math.floor(currentTime % 60);
                document.getElementById('Start').textContent = currentMinutes + ":" + (currentSeconds < 10 ? "0" + currentSeconds : currentSeconds);

                let percentage = (currentTime / duration) * 100;
                document.getElementById('ProgrssMeterChild').style.width = percentage + '%';
            }
        });

        document.getElementById('ProgressMeterContainer').addEventListener('click', function(event) {
            let rect = this.getBoundingClientRect();
            let offsetX = event.clientX - rect.left;
            let duration = audio.duration;
            if (!isNaN(duration)) {
                audio.currentTime = (offsetX / rect.width) * duration;
            }
        });

        // Set current year in the footer
        document.getElementById('Year').textContent = new Date().getFullYear();

        // Play the audio automatically when the page loads
        window.onload = function() {
            audio.play().catch(error => {
                console.log('Playback prevented by browser:', error);
                document.getElementById('PausePlay').querySelector('i').classList.replace('fa-pause', 'fa-play');
            });
        };
    </script>
</body>
</html>
