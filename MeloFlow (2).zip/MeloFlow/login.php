
<?php
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: url("/DB/images/register.jpg") center/cover fixed;
            background-size: cover;
            background-position: center;
        }

        .form-container {
            background-color: #34495e; /* Dark grayish-blue background */
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.4);
            padding: 20px;
            width: 300px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .form-container:hover {
            transform: scale(1.02);
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.6);
        }

        h1 {
            color: #ecf0f1; /* Light gray text */
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
            color: #ecf0f1;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
            border: 1px solid #2ecc71; /* Green border */
            border-radius: 4px;
            transition: border-color 0.3s ease;
        }

        input:hover,
        input:focus {
            border-color: #27ae60; /* Darker green on hover/focus */
        }

        #btn {
            background-color: #e74c3c; /* Red button */
            color: #fff;
            padding: 12px;
            margin-top: 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        #btn:hover {
            background-color: #c0392b; /* Darker red on hover */
        }
    </style>
</head>
<body>

<div class="form-container">
    <h1>Login To Meloflow</h1>
    <form name="form" action="loginProcess.php" onsubmit="return isValid()" method="POST">
        <label for="user">Username</label>
        <input type="text" id="user" name="user" required><br><br>
        <label for="pass">Password</label>
        <input type="password" id="pass" name="pass" required><br><br>
        <input type="submit" id="btn" value="Login" name="submit">
    </form>
</div>

</body>
</html>
